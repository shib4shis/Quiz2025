
  # Cyber Security Quiz Website

  This is a code bundle for Cyber Security Quiz Website. The original project is available at https://www.figma.com/design/glWCRMAln0Plql8fMa4wI8/Cyber-Security-Quiz-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  